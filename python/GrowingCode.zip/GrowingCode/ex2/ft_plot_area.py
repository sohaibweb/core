def ft_plot_area():
    x = int(input("Enter length: "))
    y = int(input("Enter width: "))

    total = x * y
    print("Plot area:", total)
